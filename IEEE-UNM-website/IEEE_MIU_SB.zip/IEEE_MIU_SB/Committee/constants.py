DESIGNATION_CHOICES = [
    (1, "Chairperson"),
    (2, "Vice Chairperson (Activity)"),
    (3, "Vice Chairperson (Technical)"),
    (4, "General Secretary"),
    (5, "Treasurer"),
    (6, "Program Committee Chair"),
    (7, "Women In Society"),
    (8, "Member Development Coordinator"),
    (9, "Technical Coordinator"),
    (10, "Publicity Coordinator"),
    (11, "Department Representative (CSE)"),
    (12, "Department Representative (EEE)"),
    (13, "Department Representative (BBA)"),
    (14, "Department Representative (B.Pharm)"),
]
gender_choices = [
    ("male", "Male"),
    ("female", "Female"),
    ("other", "Other"),
]
